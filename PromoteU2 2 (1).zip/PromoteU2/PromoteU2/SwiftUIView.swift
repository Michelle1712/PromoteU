//
//  SwiftUIView.swift
//  PromoteU2
//
//  Created by PHA-Air-5 on 8/5/22.
//

import SwiftUI

struct SideBarView: View {
    @State var showSideBar = false
    var body: some View {
        ZStack{
            if !showSideBar{
            Button(action: {
                self.showSideBar.toggle()
            }, label: {
                Image(systemName: "bullet")
                    .frame(width: 50, height: 50, alignment: .trailing)
                    .foregroundColor(.black)
                    .background(.gray)
            })
            
        }
            SideMenu(width: 370, showSideBar: showSideBar, toggleMenu: toggleMenu)
            
        }
        .edgesIgnoringSafeArea(.all)
    
    }
    func toggleMenu(){
        showSideBar.toggle()
    }
}
struct MenuItem: Identifiable{
    var id = UUID()
    let text: String
}

struct MenuContent: View{
    let items: [MenuItem] = [
    MenuItem(text: "Notifications"),
    MenuItem(text: "Help"),
    MenuItem(text: "Sign out"),
    MenuItem(text: "Switch Accounts"),
    ]
    var body: some View{
        ZStack{
            Color(UIColor(red: 33/255.0, green: 33/255.0, blue: 33/255.0, alpha: 1))
            
            VStack(alignment: .leading, spacing: 0){
                ForEach(items) {item in
                    
                }
            }
        }
    }
}
struct SideMenu: View{
    let width: CGFloat
    let showSideBar: Bool
    let toggleMenu: () -> Void
    var body: some View{
        
        ZStack{
            GeometryReader{ _ in
                EmptyView()
            }.background(.gray.opacity(0.5))
                .opacity(self.showSideBar ? 1:0)
                .animation(Animation.easeIn.delay(0.25))
            onTapGesture{
                self.toggleMenu()
            }
            HStack{
                MenuContent()
                    .frame(width: width)
                Spacer()
            }
        }
    }
}
struct SideBarView_Previews: PreviewProvider {
    static var previews: some View {
        SideBarView()
    }
}

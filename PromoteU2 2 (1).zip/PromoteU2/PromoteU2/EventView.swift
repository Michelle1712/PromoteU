//
//  EventView.swift
//  PromoteU2
//
//  Created by PHA-Air-5 on 8/5/22.
//

import SwiftUI

struct EventView: View {
    @State private var comments: String = ""
    var body: some View {
        ScrollView{
        VStack{
           
            Image("4")
                .resizable(resizingMode: .stretch)
                .frame(width: 150, height: 150)
                .overlay(
                        Circle()
                            .stroke(.white,
                                    style: StrokeStyle(lineWidth: 3, dash: [20, 5]))
                    )
                 
            Text("Pop-up Shop in Springfield")
                .foregroundColor(.white)
                .font(.system(size: 30, weight: .heavy, design: .default))
            HStack{
                Image(systemName: "calendar")
                Text("Date: 8/15/22").font(.headline).multilineTextAlignment(.leading)
            }.foregroundColor(.white)
                .padding(5)
            HStack{
            
                Image(systemName: "clock")
            
            Text("Time: 2:00pm - 7:00pm").font(.headline)
                
            }.foregroundColor(.white)
                .padding(5)
        
            HStack{
            
                Image(systemName: "globe")
            
            Text("Location: Springfield, Illinois").font(.headline)
                
            }.foregroundColor(.white)
                .padding(10)
            
            Divider()
                .frame(width: 400, height: 3)
                .overlay(.white)
                .foregroundColor(.white)
            
            Text("Event Details")
                .foregroundColor(.white)
                .font(.system(size: 30, weight: .heavy, design: .default))
        }.padding(10)
           
            Text("Our Business will be setting up a pop-up shop to introduce our newer products as well a sell our older ones. Please come support us on August 8th at 2:00pm in Springfield as we keep expanding our business.")
                .foregroundColor(.white)
                .multilineTextAlignment(.center)
                .padding(5)
            
            Divider()
                .frame(width: 400, height: 3)
                .overlay(.white)
                .foregroundColor(.white)
                .padding(5)
            
            Text("Contact Us")
                .foregroundColor(.white)
                .font(.system(size: 30, weight: .heavy, design: .default))
            
            HStack{
            
                Image(systemName: "phone.fill")
            
            Text("773-999-333").font(.headline)
                
            
            }.foregroundColor(.white)
                .padding(5)
            
            HStack{
            
                Image(systemName: "envelope")
            
            Text("OurBusiness@events.com").font(.headline)
                
            
            }.foregroundColor(.white)
            
            Divider()
                .frame(width: 400, height: 3)
                .overlay(.white)
                .foregroundColor(.white)
                .padding(5)
            
            HStack{
                TextField("Comment",
                          text: $comments)
                .background(.white.opacity(0.5))
                    .border(.secondary)
                Image(systemName: "heart.fill")
                    .frame(alignment: .leading)
                Image(systemName: "plus")
              
            }
            Text("Anggie S. liked this post")
                .foregroundColor(.white.opacity(0.7))
                      
        }.background(Image("background")
            .blur(radius: 7))
    }
}

struct EventView_Previews: PreviewProvider {
    static var previews: some View {
        EventView()
    }
}

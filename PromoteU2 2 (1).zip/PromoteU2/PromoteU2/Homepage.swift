//
//  Homepage.swift
//  PromoteU2
//
//  Created by PHA-Air-5 on 7/23/22.
//

import SwiftUI
import NSideMenu
@available(iOS 13, macCatalyst 13, tvOS 13, watchOS 6, *)
struct ScaledFont: ViewModifier {
    @Environment(\.sizeCategory) var sizeCategory
    var name: String
    var size: Double

    func body(content: Content) -> some View {
       let scaledSize = UIFontMetrics.default.scaledValue(for: size)
        return content.font(.custom(name, size: scaledSize))
    }
}

@available(iOS 13, macCatalyst 13, tvOS 13, watchOS 6, *)
extension View {
    func scaledFont(name: String, size: Double) -> some View {
        return self.modifier(ScaledFont(name: name, size: size))
    }
}
//struct MultiDatePicker<Label> where Label : View
struct EventType: Identifiable {
   
      let id: Int
      let pic: String
      let name: String
      let attendes: String
      let date: String
   
      
    }

let busy = ["8/15/22", "8/25/22","8/30/22"]

var eventTypeList = [
    EventType(id: 0, pic: "3", name: "Virtual Webinar for upcoming products", attendes: "Attendees: 100", date: "11/11/22"),
    EventType(id: 1,pic: "1", name: "Neworking with partners", attendes: "Attendees: 200", date: "12/10/22"),
    EventType(id: 2, pic: "4", name: "New product launch", attendes: "Attendees: 150", date: "12/17/23"),
    EventType(id: 3,pic: "2", name: "Pop-up shop event", attendes: "Attendees: 100", date: "12/12/22")
  ]
struct Homepage: View {
    @State private var showSideBar: Bool = false
    @State private var date = Date()
   

    init(){
            UITableView.appearance().backgroundColor = .clear
        UITableView.appearance().separatorStyle = .singleLine
             UITableViewCell.appearance().backgroundColor = UIColor(Color.clear)
      
       
        }
   
   

    @State var selectedDates: Set<DateComponents> = []
    @State private var dates = Date()

    var body: some View {
      
      
    NavigationView{
        VStack{
        VStack(spacing: -3.0){
            HStack{
            Text("Jane Doe!")
                .font(.system(size: 25).weight(.heavy))
                .multilineTextAlignment(.leading)
                
                Spacer()
                    .frame(width: 200)
                
                NavigationLink(destination: Notifications()){
                       
                    Label("",systemImage:"bell.fill")
                        .foregroundColor(.black)
                    .frame(width: 50, height: 50, alignment: .trailing)
                            .imageScale(.large)
                            .controlSize(/*@START_MENU_TOKEN@*/.large/*@END_MENU_TOKEN@*/)

            }   .badge(4)
            }
        List {
            //VStack{
               /* List {
                    Label("About", systemImage: "info.circle")
                    Label("Settings", systemImage: "gear")
                  }
                  .listStyle(SidebarListStyle())
            */
                   Section(header: Text("Current Events").foregroundColor(.white)) {
                       HStack{
                           Image("4")
                               .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width:30, height: 30)
                           
                           VStack{
                           Text("Pop-up Shop in Springfield")
                           Text("Registations: 100")
                               .font(.caption)
                               .multilineTextAlignment(.leading)
                               Text("Date: 8/15/22")
                                   .font(.caption)
                                   .foregroundColor(.green)
                           }
                       }
                       HStack{
                           Image("4")
                               .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width:30, height: 30)
                           VStack{
                       Text("Pop-up Shop in Chicago")
                               Text("Registations: 250")
                                   .font(.caption)
                                   .multilineTextAlignment(.leading)
                                   Text("Date: 8/25/22")
                                   .foregroundColor(.green)
                                   .font(.caption)
                           }
                       }
                       HStack{
                           Image("4")
                               .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width:30, height: 30)
                           VStack{
                        Text("Pop-up Shop in Palos Hieghts")
                               Text("Registations: 150")
                                   .font(.caption)
                                   .multilineTextAlignment(.leading)
                                   Text("Date: 8/30/22")
                                       .font(.caption)
                                       .foregroundColor(.green)
                           }
                       }
                       
                   
                   //}
                   }.listStyle(GroupedListStyle())
            
           Text("My Schedule:")
            DatePicker(
                   "Start Date",
                   selection: $dates,
                   displayedComponents: [.date]
                   //selectedDates = busy
               )
            .colorInvert()
                    .colorMultiply(Color.green)
               .datePickerStyle(.graphical)
        }.padding(5)
           
            
            Text("Nothing Scheduled Today")
                .foregroundColor(.white)
                
            Text("Next Event Scheduled.... 8/15/22")
                .foregroundColor(.white)
        
        }
        }.navigationTitle("Welcome Back,")
            
        .background(Image("background")
            .blur(radius: 2))
    }
    }
}
    



struct ListFooter: View {
    var body: some View {
        Text("")
    }
}

  


struct Homepage_Previews: PreviewProvider {
    static var previews: some View {
        Homepage()
      
            
        
    }
}

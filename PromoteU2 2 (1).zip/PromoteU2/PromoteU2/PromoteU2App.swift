//
//  PromoteU2App.swift
//  PromoteU2
//
//  Created by PHA-Air-5 on 7/19/22.
//

import SwiftUI


@main
struct PromoteU2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}


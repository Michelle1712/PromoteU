//
//  Profile.swift
//  PromoteU2
//
//  Created by PHA-Air-5 on 7/26/22.
//

import SwiftUI

struct Profile: View {
    @State var backgroundColor = Color.black
    init() {
        
        //UITabBar.appearance().isHidden = true
    }
    var body: some View {
        NavigationView{
        ScrollView{
            VStack{
        VStack{
            Text("Account Settings")
                .foregroundColor(.white)
                
                .position(x:200, y: 20)
                .font(.system(size: 30, weight: .heavy, design: .default))
                .multilineTextAlignment(.center)
            
                Text("Account Owner:")
                    .foregroundColor(Color.green)
                    .multilineTextAlignment(.leading)
                    .position(x: 90, y: 70)
                    .font(.system(size: 25, weight: .light, design: .default))
            
                Text("Jane Doe")
                    .foregroundColor(Color.white)
                    .multilineTextAlignment(.leading)
                    .position(x: 90, y: 70)
                    .font(.system(size: 25, weight: .bold, design: .default))
            Text("Registered email:")
                .foregroundColor(Color.green)
                .multilineTextAlignment(.leading)
                .position(x: 95, y: 70)
                .font(.system(size: 25, weight: .light, design: .default))
        }
            HStack{
            Text("OurBusiness@events.com")
                .foregroundColor(Color.white)
                .multilineTextAlignment(.leading)
                .position(x: 185, y: 70)
                .frame(width: 350, height:20 )
                .font(.system(size: 25, weight: .bold, design: .default))
                Button("edit"){
                    
                }
                .foregroundColor(.teal)
                .position(x: 40, y: 70)
                .font(.title2)
               // .frame(width: 40, height: 40)
                
                
            }
            Text("Registered Phone Number:")
                .foregroundColor(Color.green)
                .multilineTextAlignment(.leading)
                .position(x: 145, y: 70)
                .font(.system(size: 25, weight: .light, design: .default))
            HStack{
            Text("773-999-333")
                .foregroundColor(Color.white)
                .multilineTextAlignment(.leading)
                .position(x: 115, y: 70)
                .font(.system(size: 25, weight: .bold, design: .default))
                
                Button("edit"){
                    
                }
                .foregroundColor(.teal
                )
                .position(x: 180, y: 70)
                .font(.title2)
            
            
            
            }
            HStack{
                Label("", systemImage: "person.crop.circle.fill.badge.plus").foregroundColor(.teal)
                    .frame(width: 70, height: 70)
                    .position(.init(x: 40, y: 70))
                    .imageScale(.large)
                
        
            Text("Add accounts")
                .foregroundColor(Color.green)
                .multilineTextAlignment(.leading)
                .position(x: -50, y: 70)
                .font(.system(size: 25, weight: .light, design: .default))
            }
            
            HStack{
                Label("", systemImage: "lock.fill").foregroundColor(.teal)
                    .frame(width: 70, height: 70)
                    .position(.init(x: 40, y: 50))
                    .imageScale(.large)
                
        
            Text("Privacy")
                .foregroundColor(Color.green)
                .multilineTextAlignment(.leading)
                .position(x: -12, y: 50)
                .font(.system(size: 25, weight: .light, design: .default))
                
                Button(""){
                    
                }
                .foregroundColor(.teal
                )
                .position(x: 50, y: 50)
                .font(.title2)
            }
            
            HStack{
                Label("", systemImage: "bell.badge.fill").foregroundColor(.teal)
                    .frame(width: 70, height: 70)
                    .position(.init(x: 40, y: 30))
                    .imageScale(.large)
                
        
            Text("Notifications")
                .foregroundColor(Color.green)
                .multilineTextAlignment(.leading)
                .position(x: -60, y: 30)
                .font(.system(size: 25, weight: .light, design: .default))
            }
            
           
                
                
            
        VStack{
              
            Text("Account Details:")
                .foregroundColor(Color.green)
                .multilineTextAlignment(.leading)
                .position(x: 117, y: 60)
                .font(.system(size: 25, weight: .light, design: .default))
            Text("Date Registered: 10/29/23")
                .foregroundColor(Color.white)
                .multilineTextAlignment(.leading)
                .position(x: 130, y: 50)
                .font(.system(size: 16, weight: .bold, design: .default))
               
              
            
               
            Text("Deactivate Account")
            .foregroundColor(.red)
            .position(x: 210, y: 60)
            .multilineTextAlignment(.center)
            .font(.system(size: 25, weight: .light, design: .default))
                    
            Text("Delete Account")
            .foregroundColor(.red)
            .position(x: 210, y: 60)
            .multilineTextAlignment(.center)
            .font(.system(size: 25, weight: .light, design: .default))
                }
                
            .foregroundColor(.teal)
            .position(x: 200, y: 7)
            .font(.title2)
           
                VStack{
                    NavigationLink(destination: ContentView()
                        .navigationBarBackButtonHidden(true)){
                            
                            Text("Sign out")
                                //.position(x: -105, y: -570)
                                .font(.system(size: 25))
                                .frame(width: 100.0, height: 50.0)
                                .foregroundColor(.teal)
                           
                   
                }
                    
                }.hiddenNavigationBarStyle()
                
            }.background(.black.opacity(0.8))
            
            
        }.background(Image("background")
            .blur(radius: 7))
        }
        
    }
}

struct Profile_Previews: PreviewProvider {
    static var previews: some View {
        Profile()
    }
}

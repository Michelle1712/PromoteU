//
//  AddEvent.swift
//  PromoteU2
//
//  Created by PHA-Air-5 on 8/6/22.
//

import SwiftUI

struct AddEvent: View {
    var event = ["Current", "Future"]
    var icon = [Image("1"),Image("2"),Image("3"),Image("4")]
    @State private var eventName: String = ""
    @State private var description: String = ""
    @State private var date = Date()
       @State private var selectedEvent = "Red"
    @State private var selectedIcon = "1"

    var body: some View {
        ScrollView{
            VStack(alignment: .leading){
                Text("Add Events")
                    .foregroundColor(.white)
                    .font(.system(size: 30, weight: .heavy, design: .default))
                    .multilineTextAlignment(.leading)
                Picker("Please choose an event type", selection: $selectedEvent) {
                                ForEach(event, id: \.self) {
                                    Text($0)
                                }
                            }.pickerStyle(SegmentedPickerStyle())
               
                        Text("Event Name:")
                  
                    .font(.system(size: 20))
                    
                    TextField("Event Name",
                text: $eventName)
                    .background(.white.opacity(0.5))
                        .border(.secondary)
                    
                
              
                    Text("Event Description:")
                        .font(.system(size: 20))
          
                TextField("Description", text: $description)
                    .lineLimit(10)
                    .frame(width: 430, height: 200, alignment: .topLeading)
                        
                    .background(.white.opacity(0.5))
                
                      Text("Date:")
                          .font(.system(size: 20))
                DatePicker(
                       "Start Date",
                       selection: $date,
                       displayedComponents: [.date]
                   )
                   .datePickerStyle(.graphical)
                   
              //  Picker("Please choose an icon, selection: $selectedIcon,
                //displayedComponents: [.icon])
                                
            }
            VStack{
                Text("Add Event")
                    .frame(width: 100.0, height: 50.0, alignment: .center)
                    .foregroundColor(.black)
                    .background(.white)
                
                
            }
        }.background(Image("background")
            .blur(radius: 7))
    }
}

struct AddEvent_Previews: PreviewProvider {
    static var previews: some View {
        AddEvent()
        
    }
}

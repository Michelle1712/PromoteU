//
//  SwiftUIView.swift
//  PromoteU2
//
//  Created by PHA-Air-5 on 7/26/22.
//

import SwiftUI



struct My_Events: View {
    
   // @State var backgroundColor = Color.black
  
       private static var count = 0
    @State private var editMode = EditMode.inactive
       init(){
           UITableView.appearance().backgroundColor = .clear
           UITableView.appearance().separatorStyle = .singleLine
                UITableViewCell.appearance().backgroundColor = UIColor(Color.clear)
           }
      
/*private let values: [Current] = [
       Current(event: "Virtual Webinar for upcoming products", Attendees: 100, Date: "11/11/23"),
       Current(event: "", Attendees: 200, Date: ""),
       Current(event: "", Attendees: 300, Date: "")]
    
    private let value: [Future] = [
           Future(event: "Virtual Webinar for upcoming products", Attendees: 100, Date: "11/11/23"),
          Future(event: "", Attendees: 200, Date: ""),
           Future(event: "", Attendees: 300, Date: "")]
    
    private let valued: [Past] = [
           Past(event: "Virtual Webinar for upcoming products", Attendees: 100, Date: "11/11/23"),
           Past(event: "", Attendees: 200, Date: ""),
           Past(event: "", Attendees: 300, Date: "")]*/
    
    var body: some View {
        NavigationView{
           // List(Current) { event in
              //  NavigationLink(destination: EventView(event:event)) {
                
             // }
            //}
            
            
            List {
                       Section(header: Text("Current").foregroundColor(.white)) {
                          
                               
                           HStack{
                               Image("4")
                                   .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width:30, height: 30)
                               
                               VStack{
                               Text("Pop-up Shop in Springfield")
                               Text("Registations: 100")
                                   .font(.caption)
                                   .multilineTextAlignment(.leading)
                                   Text("Date: 8/15/22")
                                       .font(.caption)
                                       .foregroundColor(.green)
                               
                        
                               }
                               NavigationLink(destination: EventView()){
                                   Text("")
                            
                               }
                               
                           }
                           HStack{
                               Image("4")
                                   .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width:30, height: 30)
                               VStack{
                           Text("Pop-up Shop in Chicago")
                                   Text("Registations: 250")
                                       .font(.caption)
                                       .multilineTextAlignment(.leading)
                                       Text("Date: 8/25/22")
                                       .foregroundColor(.green)
                                       .font(.caption)
                               }
                           }
                           HStack{
                               Image("4")
                                   .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width:30, height: 30)
                               VStack{
                            Text("Pop-up Shop in Palos Hieghts")
                                   Text("Registations: 150")
                                       .font(.caption)
                                       .multilineTextAlignment(.leading)
                                       Text("Date: 8/25/22")
                                           .font(.caption)
                                           .foregroundColor(.green)
                               }
                              
                           }
                           
          
                    }
                

                Section(header: Text("Future").foregroundColor(.white)) {
                           HStack{
                               Image("3")
                                   .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width:30, height: 30)
                               VStack{
                            Text("Virtual Webinar for upcoming products")
                                   Text("Registations: 100")
                                       .font(.caption)
                                       .multilineTextAlignment(.leading)
                                       Text("Date: 9/24/22")
                                       .foregroundColor(.green)
                                           .font(.caption)
                               }
                           }
                           HStack{
                               Image("1")
                                   .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width:30, height: 30)
                               VStack{
                            Text("Neworking with partners")
                                   Text("Registations: 100")
                                       .font(.caption)
                                       .multilineTextAlignment(.leading)
                                       Text("Date: 10/11/22")
                                       .foregroundColor(.green)
                                           .font(.caption)
                               }
                           }
                           HStack{
                               Image("2")
                                   .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width:30, height: 30)
                               VStack{
                            Text("New product launch")
                                   Text("Registations: 150")
                                       .font(.caption)
                                       .multilineTextAlignment(.leading)
                                       Text("Date: 12/12/22")
                                       .foregroundColor(.green)
                                           .font(.caption)
                               }
                           }
                           HStack{
                               Image("4")
                                   .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width:30, height: 30)
                               VStack{
                            Text("Pop-up shop event in Alton")
                                   Text("Registations: 100")
                                       .font(.caption)
                                       .multilineTextAlignment(.leading)
                                       Text("Date: 12/17/22")
                                       .foregroundColor(.green)
                                           .font(.caption)
                               }
                           }
                       }
                Section(header: Text("Past").foregroundColor(.white)) {
                    HStack{
                        Image("4")
                            .resizable()
                         .aspectRatio(contentMode: .fit)
                         .frame(width:30, height: 30)
                        VStack{
                     Text("Pop-up shop event in Arlington Heights")
                            Text("Registations: 100")
                                .font(.caption)
                                .multilineTextAlignment(.leading)
                                Text("Date: 12/17/22")
                                .foregroundColor(.green)
                                    .font(.caption)
                        }
                    }
                }
            }.navigationBarTitle("My Events")
                .navigationBarItems(leading: EditButton(), trailing: addButton)
            .background( Image("background")
                .blur(radius: 7)
                .ignoresSafeArea())
        }
    }
    private var addButton: some View {
            switch editMode {
            case .inactive:
                return AnyView(Button(action: onAdd) { NavigationLink(destination: AddEvent()){ Image(systemName: "plus")} })
            default:
                return AnyView(EmptyView())
            }
        }
}
            /*List {Section(header: Text("Current"), footer: Text("")){ ForEach(values){ item in
            Design(event: item.event, Attendees: item.Attendees, Date: item.Date)
                 }
            }
        }.navigationTitle("My Events")

            List {Section(header: Text("Future"), footer: Text("")){ ForEach(value){ item in
            Design(event: item.event, Attendees: item.Attendees, Date: item.Date)
                 }
            }
        }
            List {Section(header: Text("Past"), footer: Text("")){ ForEach(valued){ item in
            Design(event: item.event, Attendees: item.Attendees, Date: item.Date)
                 }
          */  //}
        //}//.listStyle(GroupedListStyle())
  //  }
//}
//}

func onDelete(offsets: IndexSet) {
        
    }

    // 3.
 func onMove(source: IndexSet, destination: Int) {
       
    }

    
func onAdd() {
       
   }



struct My_Events_Previews: PreviewProvider {
    static var previews: some View {
        My_Events()
    }
}
    
/*struct Current: Identifiable {
let id = UUID()
var event: String
var Attendees:Int
var Date: String
   }
struct Future: Identifiable {
let id = UUID()
var event: String
var Attendees:Int
var Date: String
   }
struct Past: Identifiable {
let id = UUID()
var event: String
var Attendees:Int
var Date: String
 } /**/*/

//
//  My_Business.swift
//  PromoteU2
//
//  Created by PHA-Air-5 on 7/26/22.
//

import SwiftUI

struct My_Business: View {
    
    @State var showSideBar = false
    @State var backgroundColor = Color.black
    
  
    
    var body: some View {
        NavigationView{
        ScrollView{
            VStack{
                
                
        VStack{
           
            SideBar(sidebarWidth: 125, showSidebar: $showSideBar) {
                          
                       } content: {
                       
                       }.edgesIgnoringSafeArea(.all)
            
        
            HStack{
            Text("Business Status")
                .foregroundColor(.white)
                
                .position(x:200, y: 40)
                .font(.system(size: 30, weight: .heavy, design: .default))
                .multilineTextAlignment(.center)
                NavigationLink(destination: Notifications()){
                       
                    Label("",systemImage:"bell.fill")
                     
                    .foregroundColor(.white)
                    .frame(width: 50, height: 50, alignment: .trailing)
                            .imageScale(.large)
                            .controlSize(/*@START_MENU_TOKEN@*/.large/*@END_MENU_TOKEN@*/)

            }   .badge(4)
            
            }
            HStack{
                VStack{
                Text("1000")
                    .font(.system(size: 25, weight: .heavy, design: .default))
                    .multilineTextAlignment(.leading)
                    .foregroundColor(.green)
                    .frame(width: 200.0, height: 50.0)
                    .position(.init(x: 70, y: 100))
                    .padding(.vertical, -1)
                Text("Followers")
                    .font(.system(size: 25, weight: .heavy, design: .default))
                    .multilineTextAlignment(.leading)
                    .foregroundColor(.green)
                    .frame(width: 200.0, height: 50.0)
                    .position(.init(x: 70, y: 70))
                    .padding(.vertical, -1)
                }
                
                VStack{
                Text("5000")
                    .font(.system(size: 25, weight: .heavy, design: .default))
                    .multilineTextAlignment(.leading)
                    .foregroundColor(.green)
                    .frame(width: 200.0, height: 50.0)
                    .position(.init(x: 60, y: 100))
                    .padding(.vertical, -1)
                    
                    Text("Likes")
                        .font(.system(size: 25, weight: .heavy, design: .default))
                        .multilineTextAlignment(.leading)
                        .foregroundColor(.green)
                        .frame(width: 200.0, height: 50.0)
                        .position(.init(x: 60, y: 70))
                        .padding(.vertical, -1)
                }
                
                VStack{
                Text("6000")
                    .font(.system(size: 25, weight: .heavy, design: .default))
                    .multilineTextAlignment(.leading)
                    .foregroundColor(.green)
                    .frame(width: 200.0, height: 50.0)
                    .position(.init(x: 55, y: 100))
                    .padding(.vertical, -1)
                    
                    Text("Views")
                        .font(.system(size: 25, weight: .heavy, design: .default))
                        .multilineTextAlignment(.leading)
                        .foregroundColor(.green)
                        .frame(width: 200.0, height: 50.0)
                        .position(.init(x: 55, y: 70))
                        .padding(.vertical, -1)
                }
            }
            Text("Business Growth")
                .foregroundColor(.white)
                
                .position(x:200, y: 75)
                .font(.system(size: 30, weight: .heavy, design: .default))
                .multilineTextAlignment(.center)
            
            Label("", systemImage: "chart.line.uptrend.xyaxis").foregroundColor(.green)
                .frame(width: 70, height: 70)
                .position(.init(x: 350, y: 30))
                .imageScale(.large)
            
            VStack{
                Text("Recent")
                    .foregroundColor(Color.white)
                    .multilineTextAlignment(.leading)
                    .position(x: 50, y: 70)
                    .font(.system(size: 25, weight: .light, design: .default))
                HStack{
                    Label("", systemImage: "line.diagonal.arrow").foregroundColor(.green)
                        .frame(width: 70, height: 70)
                        .position(.init(x: 40, y: 70))
                        .imageScale(.large)
                    
                Text("Up 100 views since last week")
                    .foregroundColor(Color.white)
                    .multilineTextAlignment(.leading)
                    .position(x: -30, y: 85)
                    .font(.system(size: 25, weight: .light, design: .default))
                  //  .frame(width: 400, height: 40)
                  
                }
                HStack{
                    Label("", systemImage: "arrow.up.heart.fill").foregroundColor(.green)
                        .frame(width: 70, height: 70)
                        .position(.init(x: 40, y: 70))
                        .imageScale(.large)
                    
            
                Text("Up 100 views since last week")
                    .foregroundColor(Color.white)
                    .multilineTextAlignment(.leading)
                    .position(x: -30, y: 70)
                    .font(.system(size: 25, weight: .light, design: .default))
                }
                VStack{
                Text("Past Month")
                    .foregroundColor(Color.white)
                    .multilineTextAlignment(.leading)
                    .position(x: 65, y: 70)
                    .font(.system(size: 25, weight: .light, design: .default))
                    
                    HStack{
                        Label("", systemImage: "arrow.up.heart.fill").foregroundColor(.green)
                            .frame(width: 70, height: 70)
                            .position(.init(x: 40, y: 70))
                            .imageScale(.large)
                        
                    Text("Up 200 views")
                        .foregroundColor(Color.white)
                        .multilineTextAlignment(.center)
                        .position(x: -60, y: 70)
                        .font(.system(size: 25, weight: .light, design: .default))
                        
                        
                    }
                    HStack{
                        Label("", systemImage: "arrow.down.heart.fill").foregroundColor(.green)
                            .frame(width: 70, height: 70)
                            .position(.init(x: 40, y: 40))
                            .imageScale(.large)
                        
                    Text("Down 50 likes")
                        .foregroundColor(Color.white)
                        .multilineTextAlignment(.center)
                        .position(x: -60, y: 40)
                        .font(.system(size: 25, weight: .light, design: .default))
                        
                        
                    }
                }
            }
        }
            }.background(.black.opacity(0.8))
                
        }//.navigationBarTitle("My Business")
               // .navigationBarItems( trailing: SideBar<<#SidebarContent: View#>, <#Content: View#>>)
                .background(Image("background")
                        .blur(radius: 7))
    }
    }
   
    

}

              
 
                         

struct My_Business_Previews: PreviewProvider {
    static var previews: some View {
        My_Business()
    }
}

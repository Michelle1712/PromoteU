//
//  Tabs.swift
//  PromoteU2
//
//  Created by PHA-Air-5 on 7/26/22.
//

import SwiftUI

struct Tabs: View {
    
    
  
    init() {
    //Set tab bar appearance
        
        
        UITabBar.appearance().backgroundColor = .black
        UITabBar.appearance().barTintColor = UIColor.black //Tab bar color
    UITabBar.appearance().unselectedItemTintColor = UIColor.green //Tab item color when not selected
        UITabBar.appearance().isOpaque = false
        
    }
    var body: some View {
       
        
        TabView(/*selection: $selection*/ ){
            Homepage()
                .tag(1)
               
                //.environmentObject(router)
                .tabItem
            {
                Label("My Feed", systemImage: "globe")
                //selection = 1
            }
            My_Business()
                .tag(2)
                .tabItem
                    {
                        Label("My Business", systemImage: "briefcase.fill")
                      //  selection = 2
                    }
            My_Events()
                .tag(3)
            
                .tabItem
                {
                    Label("My Events", systemImage: "map.circle")
                   // selection = 3
                    
                }
            Profile()
                .tag(4)
           
                .tabItem
                {
                    Label("Profile", systemImage: "person.circle.fill")
                    
                }
        }.accentColor(.teal)
            .background(Color.black)
            .accessibilityIdentifier("$selection")
    }
    }
struct Tabs_Previews: PreviewProvider {
    static var previews: some View {
        Tabs()
        
    }
}

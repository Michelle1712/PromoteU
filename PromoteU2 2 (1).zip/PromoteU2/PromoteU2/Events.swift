//
//  Events.swift
//  PromoteU2
//
//  Created by PHA-Air-5 on 7/31/22.
//

import Foundation
struct Events: View {
    var tutors: [Tutor] = []
 
    var body: some View {
        List(tutors) { tutor in
            Image(tutor.imageName)
            VStack(alignment: .leading) {
                Text(tutor.name)
                Text(tutor.headline)
                    .font(.subheadline)
                    .color(.gray)
            }
        }
    }
}

//
//  Register.swift
//  PromoteU2
//
//  Created by PHA-Air-5 on 8/6/22.
//

import SwiftUI

struct Register: View {
    @State private var fname: String = ""
    @State private var lname: String = ""
    @State private var email: String = ""
    @State private var phone: String = ""
    @State private var password: String = ""
    @State private var passwords: String = ""
    @State private var business: String = ""
    var body: some View {
        ScrollView{
   
            VStack(alignment: .leading){
                
                Text("Registration")
                    .foregroundColor(.white)
                    .font(.system(size: 30, weight: .heavy, design: .default))
                    .padding(5)
                    
                    Text("First Name:")
                        .foregroundColor(.white)
                .font(.system(size: 20))
                
                TextField("First Name",
            text: $fname)
                .background(.white.opacity(0.5))
                    .border(.secondary)
                
                Text("Last Name:")
                    .foregroundColor(.white)
            .font(.system(size: 20))
            
            TextField("Last Name",
        text: $lname)
            .background(.white.opacity(0.5))
                .border(.secondary)
            
                Text("Email:")
                    .foregroundColor(.white)
            .font(.system(size: 20))
            
            TextField("Email",
        text: $email)
            .background(.white.opacity(0.5))
                .border(.secondary)
                
            
                Text("Phone Number:")
                    .foregroundColor(.white)
            .font(.system(size: 20))
            
            TextField("Phone Number",
        text: $phone)
            .background(.white.opacity(0.5))
                .border(.secondary)
                
                VStack(alignment: .leading){
                    Text("Business Name:")
                        .foregroundColor(.white)
                .font(.system(size: 20))
                
                TextField("Business Name",
            text: $business)
                .background(.white.opacity(0.5))
                    .border(.secondary)
                    .padding(5)
                    
                    Text("Password:")
                        .foregroundColor(.white)
                .font(.system(size: 20))
                
                    HStack{
                    TextField("Password",
                text: $password)
                    .background(.white.opacity(0.5))
                        .border(.secondary)
                        Image(systemName: "eye.slash")
                            .foregroundColor(.white)
                    }
                    Text("Confirm Password:")
                        .foregroundColor(.white)
                .font(.system(size: 20))
                
                    HStack{
                    TextField("Password",
                text: $passwords)
                    .background(.white.opacity(0.5))
                        .border(.secondary)
                        Image(systemName: "eye.slash")
                            .foregroundColor(.white)
                            
                    }
                    
                  
                  
                }
               
               

            
                
            }
            Text("Register")
                .frame(width: 200, height: 50, alignment: .center)
                .foregroundColor(.black)
                .background(.gray)
                .font(.system(size: 20, weight: .heavy))
                .padding(30)
            
        }.background(.black)
    }
}

struct Register_Previews: PreviewProvider {
    static var previews: some View {
        Register()
    }
}

//
//  ContentView.swift
//  PromoteU2
//
//  Created by PHA-Air-5 on 7/19/22.
//

import SwiftUI

struct ContentView: View {
    
    @State var backgroundColor = Color.black
    @State private var username: String = ""
    @State private var password: String = ""
    //@EnvironmentObject var router: TabRouter
    
    init(){
            UITableView.appearance().backgroundColor = .clear
       //UITabBar.appearance().isHidden = true
        }
    var body: some View {
       
        
    NavigationView{
        
        VStack(alignment: .center){
            
            
            Text("PromoteU")
                .font(.title)
                .fontWeight(.heavy)
                .multilineTextAlignment(.center)
                .foregroundColor(.green)
            
            Image("logo")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(width: 200, height: 150)
            
            Text("Login")
                .font(.title)
                .fontWeight(.heavy)
                .multilineTextAlignment(.center)
                .foregroundColor(.green)
                
       Form {
            

            TextField(text: $username, prompt: Text("Email/Username")) {
                    Text("Username")
                    .textContentType(.emailAddress)
                                   .padding(.init(top: 0, leading: 15, bottom:0 , trailing: 15))
                    
                    .frame(width: 370.0, height: 50.0, alignment: .center)
                    
                    .textFieldStyle(RoundedBorderTextFieldStyle.init())
                
                keyboardType(.default)
                               
                    
            }
            .ignoresSafeArea(.keyboard, edges: .bottom)
            

                SecureField(text: $password, prompt: Text("Password")) {
                    Text("Password")
                        .textContentType(.password)
                                       .padding(.init(top: 0, leading: 15, bottom:0 , trailing: 15))
                    
                        .frame(width: 370.0, height: 50.0, alignment: .center)
                       
                        .textFieldStyle(RoundedBorderTextFieldStyle.init())
                    keyboardType(.default)
                }
            
                .ignoresSafeArea(.keyboard, edges: .bottom)
               
            }
        
            
            
            Text("Forgot Password?")
                .font(.subheadline)
                .fontWeight(.heavy)
                .multilineTextAlignment(.leading)
                .foregroundColor(.green)
                .frame(width: 200.0, height: 50.0)
                .position(.init(x: 70, y: 1))
                .padding(.vertical, -1)
            HStack{
                Text("Don't have an account? ")
                    .font(.subheadline)
                    .fontWeight(.heavy)
                    .multilineTextAlignment(.leading)
                    .foregroundColor(.green)
                    .position(x: 90, y: 1)
                    .padding(.vertical, -115)
                NavigationLink(destination: Register()
                    ){
                Text("Register")
                    
                }
                .foregroundColor(.green)
                .position(x: 125, y: 1)
                .padding(.vertical, -120)
                
                
                    }
            
           
            NavigationLink(destination: Tabs()
                .navigationBarBackButtonHidden(true)){
                    
            Text("Login")
                
                .frame(width: 100.0, height: 50.0)
                .foregroundColor(.black)
                .background(.green)
            }
            
            
            
            
           
        }
            .padding()
            .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity, alignment: .center)
            .background(.black)
           .hiddenNavigationBarStyle()
    }
        
}
    
        
}
struct HiddenNavigationBar: ViewModifier {
    func body(content: Content) -> some View {
        content
        .navigationBarTitle("", displayMode: .inline)
        .navigationBarHidden(true)
    }
}

extension View {
    func hiddenNavigationBarStyle() -> some View {
        modifier( HiddenNavigationBar() )
    }
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
          
    }
}


//
//  Design.swift
//  PromoteU2
//
//  Created by PHA-Air-5 on 8/3/22.
//
import SwiftUI
import Foundation
struct Design: View {
    
    @State var event: String
    @State var Attendees: Int
    @State var Date: String
    
    var body: some View {
        ZStack(alignment: .leading){
            RoundedRectangle(cornerRadius: 10.0)
                .colorScheme(.light)
                .frame(height: 50)
                .background( Image("background")
                    .blur(radius: 7)
                    .ignoresSafeArea())
            
            VStack(alignment: .leading){
                Text(event)
                    .foregroundColor(.white)
                    .font(.subheadline)
                Text("\(Attendees)")
                    .foregroundColor(.white)
                    .font(.caption)
                Text(Date)
                    .foregroundColor(.white)
                    .font(.caption2)
            }
            .padding()
        }.listStyle(GroupedListStyle())
        .padding()
    }
}
struct Design_Previews: PreviewProvider {
    static var previews: some View {
        Design(event: "", Attendees: 200, Date: "" )
    }
}

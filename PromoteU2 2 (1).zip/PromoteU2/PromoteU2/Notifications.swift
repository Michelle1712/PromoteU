//
//  Notifications.swift
//  PromoteU2
//
//  Created by PHA-Air-5 on 7/28/22.
//

import SwiftUI

struct notifications: Identifiable{
    var id = UUID()
    var message: String
}
struct notiRow: View {
    var noti: notifications
    var body: some View {
        Text(noti.message)
    
}
}
struct Notifications: View {
    init(){
       
        UITableView.appearance().backgroundColor = .clear
        UITableView.appearance().separatorStyle = .singleLine
             UITableViewCell.appearance().backgroundColor = UIColor(Color.clear)
      
        UINavigationBarAppearance().backgroundColor = UIColor(Color.clear)
        }
    let notification = [
        notifications( message: "New interaction on event in Springfield"),
       notifications( message: "New comment on event in Chicago"),
       notifications( message: "New comment on event in Arlingtion"),
       notifications( message: "New follower ")
    ]
    
   
    var body: some View {
        NavigationView{
            
            
            List(notification) { noti in
              
                NavigationLink(destination: EventView().navigationBarHidden(true)){
                notiRow (noti:noti)
               
            }
            }
            .navigationTitle("Notifications")
           
    .background(Image("background")
                    .blur(radius: 7))
        }
    }
}

struct DetailView: View {
    var noti: notifications
    
    var body: some View {
        VStack {
            Text(noti.message).font(.title)
            
            HStack {
                
            }
            
            Spacer()
        }.background(Image("background")
            .blur(radius: 7))
    }
}
struct ListHeader: View {
    var body: some View {
        HStack {
            Image(systemName: "globe")
            Text("Click to view details")
        }
    }
}
struct Notifications_Previews: PreviewProvider {
    static var previews: some View {
        Notifications()
    }
}
